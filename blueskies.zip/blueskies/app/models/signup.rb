class Signup < ActiveRecord::Base
	belongs_to :volunteer
end
