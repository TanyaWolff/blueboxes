module GateHelper
end
