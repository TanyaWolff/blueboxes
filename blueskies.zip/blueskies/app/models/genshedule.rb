class Shedule < ActiveRecord::Base
end
