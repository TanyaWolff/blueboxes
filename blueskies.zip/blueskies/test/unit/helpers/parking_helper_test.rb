require 'test_helper'

class ParkingHelperTest < ActionView::TestCase
end
