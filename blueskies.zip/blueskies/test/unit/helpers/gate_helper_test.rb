require 'test_helper'

class GateHelperTest < ActionView::TestCase
end
