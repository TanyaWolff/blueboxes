require 'test_helper'

class ShiftsHelperTest < ActionView::TestCase
end
