class DutyController < ApplicationController
	def index
		
	end
	
  

end
