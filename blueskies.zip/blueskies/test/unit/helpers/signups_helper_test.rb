require 'test_helper'

class SignupsHelperTest < ActionView::TestCase
end
