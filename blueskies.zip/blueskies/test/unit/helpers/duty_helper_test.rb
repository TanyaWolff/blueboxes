require 'test_helper'

class DutyHelperTest < ActionView::TestCase
end
