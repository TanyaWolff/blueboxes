# This file is auto-generated from the current state of the database. Instead of editing this file, 
# please use the migrations feature of Active Record to incrementally modify your database, and
# then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your database schema. If you need
# to create the application database on another system, you should be using db:schema:load, not running
# all the migrations from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20120610170434) do

  create_table "areas", :force => true do |t|
    t.string   "name"
    t.text     "description"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "comments", :force => true do |t|
    t.text     "entry"
    t.integer  "volunteer_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "locations", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "area_id"
  end

  create_table "locations_schedules", :id => false, :force => true do |t|
    t.integer "schedule_id"
    t.integer "location_id"
  end

  create_table "pictures", :force => true do |t|
    t.string   "name"
    t.string   "comment"
    t.string   "content_type"
    t.binary   "data",         :limit => 1048576
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "path"
  end

  create_table "schedules", :force => true do |t|
    t.string   "title"
    t.integer  "year"
    t.text     "description"
    t.date     "start"
    t.date     "end"
    t.integer  "shiftlength"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "area_id"
    t.integer  "status",      :default => 0
  end

  create_table "sessions", :force => true do |t|
    t.string   "session_id", :null => false
    t.text     "data"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "sessions", ["session_id"], :name => "index_sessions_on_session_id"
  add_index "sessions", ["updated_at"], :name => "index_sessions_on_updated_at"

  create_table "shifts", :force => true do |t|
    t.datetime "start"
    t.integer  "location_id"
    t.integer  "volunteer_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "schedule_id"
  end

  create_table "signups", :force => true do |t|
    t.integer  "volunteer_id"
    t.integer  "year"
    t.integer  "tix_ad"
    t.integer  "tix_st"
    t.integer  "tix_ch"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "volunteers", :force => true do |t|
    t.string   "name"
    t.string   "email"
    t.string   "profile"
    t.string   "hashed_pw"
    t.string   "salt"
    t.boolean  "key"
    t.boolean  "hat"
    t.integer  "hours",          :default => 10
    t.string   "restrictions"
    t.string   "shiftlength"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "phone"
    t.string   "cell"
    t.boolean  "share"
    t.boolean  "thursday"
    t.integer  "early"
    t.integer  "late"
    t.integer  "dinner"
    t.integer  "best_loc"
    t.integer  "worst_loc"
    t.boolean  "gate"
    t.boolean  "inner"
    t.string   "first_name"
    t.string   "last_name"
    t.boolean  "friday_pm"
    t.boolean  "monday_am"
    t.boolean  "monday_pm"
    t.boolean  "old_hat"
    t.integer  "first_year_bs"
    t.integer  "first_year_key"
    t.string   "address"
    t.integer  "tickets"
    t.integer  "tix_students"
    t.integer  "tix_kids"
    t.integer  "area_id"
    t.integer  "picture_id"
  end

end
