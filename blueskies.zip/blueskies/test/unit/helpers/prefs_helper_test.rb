require 'test_helper'

class PrefsHelperTest < ActionView::TestCase
end
