module DutyHelper
end
