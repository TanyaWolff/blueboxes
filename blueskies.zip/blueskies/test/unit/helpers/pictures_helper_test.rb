require 'test_helper'

class PicturesHelperTest < ActionView::TestCase
end
