require 'test_helper'

class VolunteersHelperTest < ActionView::TestCase
end
